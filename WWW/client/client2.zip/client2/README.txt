README (OUTDATED >> TO BE UPDATED)
======

PREINSTALLATION
===============
Run the add.bat file to determine the Hostname to Web Register with.

INSTALLATION
============
Place the two files in C:\openlabs
run.vbs should be used when running as a service (set up in Group Policy or in Task Scheduler)
client.exe is the program that updates the database.

REMOVAL
=======
These programs do not leave any trace or files in the computer. Because of this, the programs
can just be deleted off the drive and nothing will be left behind. If the program was set up in
Group Policy or Task Scheduler, then it will need to be removed manually.

NOTES
=====
**This software is provided without warranty and the developer will not be held responsible for
any damages caused. This software is tested periodically for functionality and for performance
checks (CPU Usage / Network Usage).**