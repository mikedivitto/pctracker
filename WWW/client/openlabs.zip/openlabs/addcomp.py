#Michael Divitto
#Open Labs - Add Computer
import socket
import urllib2
import urllib
hname = socket.gethostname()
bldg = raw_input('Enter Building: ')
room = raw_input('Enter Room Number: ')
comp = raw_input('Enter Computer Number: ')
os = raw_input('Enter OS Type i.e. Linux, Mac, Windows: ')
url = "http://cs.newpaltz.edu/~n02482434/openlabs/func/insert.php"
values = {'hname' : hname,
		  'bldg' : bldg,
		  'room' : room,
		  'comp' : comp,
		  'srvc' : "0",
		  'os' : os}
data = urllib.urlencode(values)
try:
	test = urllib2.urlopen(url,data)
except urllib2.HTTPError, err:
	print "HTTP Error."
except urllib2.URLError, err:
	print "HTTP Error."
