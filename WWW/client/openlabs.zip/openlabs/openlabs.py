#Michael Divitto
#Open Labs - Client
import socket
import getpass
import time
import urllib2
import urllib
hname = '"' + socket.gethostname() + '"'
uname = '"' + getpass.getuser() + '"'
url = "http://cs.newpaltz.edu/~n02482434/openlabs/func/update.php"
while True:
	tstamp = '"' + str(time.time()) + '"'
	values = {'hname' : hname,
			  'uname' : uname,
			  'tstamp' : tstamp }
	data = urllib.urlencode(values)
	furl = url + '?' + data
	try:
		test = urllib2.urlopen(furl)
	except urllib2.HTTPError, err:
		continue;
	except urllib2.URLError, err:
		continue;
	time.sleep(10)
